''' Languages data.'''
